#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import os
import json
import uuid
import time
import random
import string
from datetime import datetime
import re
from collections import defaultdict

ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
DB_DIR = os.path.join(ROOT_DIR, 'database')
DATA_DIR = os.path.join(ROOT_DIR, 'data')

ADMIN_PASSWORD = os.environ.get('ADMIN_PASSWORD', '700307')

VALID_NAMES = [
    '张婧琪', '桑心雨', '王小匀', '张诗童', '张诗涵',
    '王爽', '董贞', '肖俊杰', '张晓彤', '杨敏', '胡志涛',
    '程欣茹', '冯如意', '石建', '李凤芹', '康智傲', '苑诗然',
    '刘丹', '陈舒婷', '吴彦硕', '马煜', '刘亮', '刘儒静',
    '谢文亚', '和雅洁', '梁园园', '施梦涵', '张家乐', '高浩仁',
    '朱文茹', '刘朔彤', '刘嘉欣', '王梓骁', '王博霖', '张书婷',
    '刘媛', '泰迪', '张亚柔', '高志浩', '孙豪杰', '袁誉通',
    '董潇'
]

ALLOWED_EXT = {'.mp4', '.webm', '.avi', '.mov', '.mkv', '.flv'}

app = Flask(__name__, static_folder=ROOT_DIR)
CORS(app, resources={r"/api/*": {"origins": ""}})

os.makedirs(DB_DIR, exist_ok=True)
os.makedirs(DATA_DIR, exist_ok=True)

app.config['MAX_CONTENT_LENGTH'] = 500 * 1024 * 1024  # 500 MB


@app.errorhandler(413)
def _request_entity_too_large(e):
    return jsonify({'error': '文件过大，最大支持 500MB'}), 413


# ---------------------------------------------------------------------------
# JSON helpers
# ---------------------------------------------------------------------------

def _db_path(name):
    return os.path.join(DB_DIR, name)


def read_json(name):
    path = _db_path(name)
    if not os.path.exists(path) or os.path.getsize(path) == 0:
        return []
    with open(path, 'r', encoding='utf-8') as f:
        try:
            return json.load(f)
        except json.JSONDecodeError:
            return []


def write_json(name, data):
    path = _db_path(name)
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


# ---------------------------------------------------------------------------
# UA parser (lightweight, no extra deps)
# ---------------------------------------------------------------------------

def parse_ua(ua_str):
    ua = ua_str.lower()
    # OS
    if 'windows' in ua:
        os_name = 'Windows'
    elif 'mac os' in ua or 'macintosh' in ua:
        os_name = 'macOS'
    elif 'android' in ua:
        os_name = 'Android'
    elif 'ios' in ua or 'iphone' in ua or 'ipad' in ua:
        os_name = 'iOS'
    elif 'linux' in ua:
        os_name = 'Linux'
    else:
        os_name = 'Unknown'

    # Device type
    if 'ipad' in ua:
        device = 'Tablet'
    elif 'ipod' in ua:
        device = 'Music Player'
    elif 'iphone' in ua:
        device = 'Phone'
    elif 'android' in ua and 'mobile' in ua:
        device = 'Phone'
    elif 'android' in ua:
        device = 'Tablet'
    elif 'windows' in ua:
        device = 'Desktop'
    elif 'mac os' in ua or 'macintosh' in ua:
        device = 'Desktop'
    elif 'linux' in ua:
        device = 'Desktop'
    else:
        device = 'Unknown'

    # Browser
    if 'edg/' in ua or 'edge/' in ua:
        browser = 'Edge'
    elif 'firefox' in ua and 'seamonkey' not in ua:
        browser = 'Firefox'
    elif 'chrome' in ua and 'chromium' not in ua:
        browser = 'Chrome'
    elif 'safari' in ua and 'chrome' not in ua:
        browser = 'Safari'
    elif 'trident' in ua:
        browser = 'IE'
    else:
        browser = 'Unknown'

    return os_name, device, browser


# ---------------------------------------------------------------------------
# Database init & sync
# ---------------------------------------------------------------------------

def _next_video_id(videos):
    """Return a monotonically increasing ID that never reuses old IDs."""
    max_id = max((v['id'] for v in videos), default=0)
    return max_id + 1


def sync_database():
    """Sync video database with data/ directory on startup."""
    videos = read_json('videos.json')
    existing = {v['filename'] for v in videos}
    changed = False

    for fname in os.listdir(DATA_DIR):
        ext = os.path.splitext(fname)[1].lower()
        if ext not in ALLOWED_EXT:
            continue
        if fname in existing:
            continue
        fp = os.path.join(DATA_DIR, fname)
        mtime = os.path.getmtime(fp)
        videos.append({
            'id': _next_video_id(videos),
            'title': os.path.splitext(fname)[0],
            'filename': fname,
            'path': f'data/{fname}',
            'uploaded_at': datetime.fromtimestamp(mtime).strftime('%Y-%m-%d %H:%M:%S'),
            'updated_at': datetime.fromtimestamp(mtime).strftime('%Y-%m-%d %H:%M:%S'),
            'play_count': 0,
            'unique_ips': []
        })
        changed = True

    # Prune entries whose file no longer exists
    before = len(videos)
    videos = [v for v in videos if os.path.exists(os.path.join(DATA_DIR, v['filename']))]
    if len(videos) != before:
        changed = True

    if changed:
        write_json('videos.json', videos)

    if not os.path.exists(_db_path('visitors.json')):
        write_json('visitors.json', [])

    if not os.path.exists(_db_path('shares.json')):
        write_json('shares.json', [])

    if not os.path.exists(_db_path('uploads.json')):
        write_json('uploads.json', [])


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _safe_filename(base_name, ext):
    """Generate a unique filename based on title, appending a number if conflict."""
    safe_base = re.sub(r'[\\/*?:"<>|]', '_', base_name)
    filename = f"{safe_base}{ext}"
    counter = 1
    while os.path.exists(os.path.join(DATA_DIR, filename)):
        filename = f"{safe_base}_{counter}{ext}"
        counter += 1
    return filename


def get_client_ip():
    """Extract real client IP."""
    xff = request.headers.get('X-Forwarded-For')
    if xff:
        return xff.split(',')[0].strip()
    return request.remote_addr or '0.0.0.0'


def require_admin():
    """Check admin password from header."""
    pwd = request.headers.get('X-Admin-Password')
    if pwd != ADMIN_PASSWORD:
        return None
    return True


# ===================================================================
# Security helpers & headers
# ===================================================================

_rate_limit_buckets = defaultdict(list)


def _check_rate_limit(key, max_attempts=10, window=60):
    """Simple in-memory rate limiter per key."""
    now = time.time()
    bucket = _rate_limit_buckets[key]
    bucket[:] = [t for t in bucket if now - t < window]
    if len(bucket) >= max_attempts:
        return False
    bucket.append(now)
    return True


def _sanitize_html(text):
    """Strip HTML tags for XSS prevention."""
    if not isinstance(text, str):
        return text
    return re.sub(r'<[^>]*>', '', text)


@app.after_request
def _security_headers(resp):
    csp = (
        "default-src 'self'; "
        "style-src 'self' 'unsafe-inline' https://gcore.jsdelivr.net https://cdn.bootcdn.net; "
        "font-src 'self' https://gcore.jsdelivr.net https://cdn.bootcdn.net; "
        "script-src 'self' 'unsafe-inline'; "
        "media-src 'self'; "
        "img-src 'self' data:; "
        "connect-src 'self'"
    )
    resp.headers['Content-Security-Policy'] = csp
    resp.headers['X-Content-Type-Options'] = 'nosniff'
    resp.headers['X-Frame-Options'] = 'DENY'
    resp.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'
    return resp


# ===================================================================
# API – Public
# ===================================================================

@app.route('/api/verify', methods=['POST'])
def api_verify():
    data = request.get_json(silent=True) or {}
    name = data.get('name', '').strip()

    # Rate limit by IP
    if not _check_rate_limit(f'verify:{get_client_ip()}', max_attempts=10, window=60):
        return jsonify({'valid': False, 'message': '操作过于频繁，请稍后再试'})

    if not name:
        return jsonify({'valid': False, 'message': '请先输入你的名字'})

    if name == '康神':
        return jsonify({'valid': False, 'message': '康神还没有开播，不通过'})

    if name == '程煜':
        return jsonify({'valid': False, 'message': '别输你爹名字，不通过'})

    if name in VALID_NAMES:
        return jsonify({'valid': True, 'message': '验证通过'})

    return jsonify({'valid': False, 'message': '身份未通过验证，请确认你的名字'})


@app.route('/api/videos', methods=['GET'])
def api_videos():
    search = request.args.get('search', '').strip().lower()
    sort_by = request.args.get('sort', 'newest')

    videos = read_json('videos.json')

    # Filter
    if search:
        videos = [v for v in videos if search in v['title'].lower()]

    # Sort
    if sort_by == 'newest':
        videos.sort(key=lambda v: v.get('updated_at', ''), reverse=True)
    elif sort_by == 'oldest':
        videos.sort(key=lambda v: v.get('updated_at', ''))
    elif sort_by == 'most_played':
        # Use unique_ips length as play count
        videos.sort(key=lambda v: len(v.get('unique_ips', [])), reverse=True)
    elif sort_by == 'least_played':
        videos.sort(key=lambda v: len(v.get('unique_ips', [])), reverse=False)

    # Return safe fields only
    result = []
    for v in videos:
        result.append({
            'id': v['id'],
            'title': v['title'],
            'path': v['path'],
            'uploader': v.get('uploader', ''),
            'uploaded_at': v.get('uploaded_at', ''),
            'updated_at': v.get('updated_at', ''),
            'play_count': len(v.get('unique_ips', [])),
        })

    return jsonify(result)


@app.route('/api/logs/visit', methods=['POST'])
def api_log_visit():
    data = request.get_json(silent=True) or {}
    name = data.get('name', '').strip()
    ua_str = request.headers.get('User-Agent', '')
    ip = get_client_ip()
    os_name, device, browser = parse_ua(ua_str)

    visit_id = uuid.uuid4().hex[:16]
    now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    logs = read_json('visitors.json')
    logs.append({
        'id': visit_id,
        'name': name,
        'ip': ip,
        'ua': ua_str,
        'os': os_name,
        'device': device,
        'browser': browser,
        'visited_at': now,
        'video_watched': None
    })
    write_json('visitors.json', logs)

    return jsonify({'visit_id': visit_id})


@app.route('/api/logs/watch', methods=['POST'])
def api_log_watch():
    data = request.get_json(silent=True) or {}
    visit_id = data.get('visit_id', '')
    video_title = data.get('video_title', '').strip()

    if not visit_id:
        return jsonify({'error': 'visit_id required'}), 400

    logs = read_json('visitors.json')
    updated = False
    for log in logs:
        if log['id'] == visit_id:
            log['video_watched'] = video_title
            updated = True
            break

    if updated:
        write_json('visitors.json', logs)

    # Update video unique-ip tracking
    if video_title:
        ip = get_client_ip()
        videos = read_json('videos.json')
        vid_updated = False
        for v in videos:
            if v['title'] == video_title:
                ips = v.setdefault('unique_ips', [])
                if ip not in ips:
                    ips.append(ip)
                    v['play_count'] = len(ips)
                    v['updated_at'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                    vid_updated = True
                break
        if vid_updated:
            write_json('videos.json', videos)

    return jsonify({'success': True})


# ===================================================================
# API – Public Upload (verified users)
# ===================================================================

@app.route('/api/upload', methods=['POST'])
def api_public_upload():
    # Rate limit: 1 upload per IP per 60 seconds
    if not _check_rate_limit(f'upload:{get_client_ip()}', max_attempts=1, window=60):
        return jsonify({'error': '每个IP每分钟只能上传一个视频，请稍后再试'}), 429

    if 'video' not in request.files:
        return jsonify({'error': '请选择视频文件'}), 400

    file = request.files['video']
    title = request.form.get('title', '').strip()
    uploader = request.form.get('uploader', '').strip()

    if not uploader:
        return jsonify({'error': '请先验证身份'}), 400

    if file.filename == '':
        return jsonify({'error': '请选择视频文件'}), 400

    # Validate file extension
    ext = os.path.splitext(file.filename)[1].lower()
    if ext not in ALLOWED_EXT:
        return jsonify({'error': f'不支持的文件格式 {ext}'}), 400

    # Validate MIME type
    mime = (file.content_type or '').lower()
    if not mime.startswith('video/'):
        return jsonify({'error': '不支持的文件类型，请上传视频文件'}), 400

    # Check file size (max 50 MB) — seek to end
    file.stream.seek(0, os.SEEK_END)
    size = file.stream.tell()
    file.stream.seek(0)
    if size > 50 * 1024 * 1024:
        return jsonify({'error': '文件过大，最大支持 50MB'}), 413
    if size == 0:
        return jsonify({'error': '文件为空'}), 400

    # Sanitize title
    base_name = _sanitize_html(title) if title else _sanitize_html(os.path.splitext(file.filename)[0])
    safe_name = _safe_filename(base_name, ext)
    file.save(os.path.join(DATA_DIR, safe_name))

    now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    ip = get_client_ip()

    # Add to videos database
    videos = read_json('videos.json')
    new_id = _next_video_id(videos)
    new_video = {
        'id': new_id,
        'title': base_name,
        'filename': safe_name,
        'path': f'data/{safe_name}',
        'uploader': _sanitize_html(uploader),
        'uploaded_at': now,
        'updated_at': now,
        'play_count': 0,
        'unique_ips': []
    }
    videos.append(new_video)
    write_json('videos.json', videos)

    # Record upload log
    uploads = read_json('uploads.json')
    size_mb = round(size / (1024 * 1024), 2)
    uploads.append({
        'id': len(uploads) + 1,
        'ip': ip,
        'uploader': _sanitize_html(uploader),
        'title': base_name,
        'filename': safe_name,
        'video_id': new_id,
        'size_mb': size_mb,
        'uploaded_at': now
    })
    write_json('uploads.json', uploads)

    return jsonify({'success': True, 'video': new_video})


# ===================================================================
# API – Admin
# ===================================================================

@app.route('/api/admin/verify', methods=['POST'])
def api_admin_verify():
    data = request.get_json(silent=True) or {}

    # Rate limit by IP (stricter for admin)
    if not _check_rate_limit(f'admin_verify:{get_client_ip()}', max_attempts=5, window=60):
        return jsonify({'success': False}), 429

    if data.get('password') == ADMIN_PASSWORD:
        return jsonify({'success': True})
    return jsonify({'success': False}), 401


@app.route('/api/admin/visitors', methods=['GET'])
def api_admin_visitors():
    if not require_admin():
        return jsonify({'error': '未授权'}), 401
    logs = read_json('visitors.json')
    # Return newest first
    logs.reverse()
    return jsonify(logs)


@app.route('/api/admin/visitors/clear', methods=['POST'])
def api_admin_visitors_clear():
    if not require_admin():
        return jsonify({'error': '未授权'}), 401
    write_json('visitors.json', [])
    return jsonify({'success': True})


@app.route('/api/admin/stats', methods=['GET'])
def api_admin_stats():
    if not require_admin():
        return jsonify({'error': '未授权'}), 401

    logs = read_json('visitors.json')
    videos = read_json('videos.json')

    # IP access count
    ip_count = {}
    for log in logs:
        ip = log.get('ip', 'Unknown')
        ip_count[ip] = ip_count.get(ip, 0) + 1
    ip_stats = sorted([{'ip': k, 'count': v} for k, v in ip_count.items()],
                      key=lambda x: x['count'], reverse=True)

    # Name usage count
    name_count = {}
    for log in logs:
        name = log.get('name', 'Unknown')
        name_count[name] = name_count.get(name, 0) + 1
    name_stats = sorted([{'name': k, 'count': v} for k, v in name_count.items()],
                        key=lambda x: x['count'], reverse=True)

    # Video play count (unique IP)
    video_stats = []
    for v in videos:
        video_stats.append({
            'title': v['title'],
            'play_count': len(v.get('unique_ips', [])),
            'filename': v['filename']
        })
    video_stats.sort(key=lambda x: x['play_count'], reverse=True)

    return jsonify({
        'ip_stats': ip_stats,
        'name_stats': name_stats,
        'video_stats': video_stats,
        'total_visits': len(logs)
    })


@app.route('/api/admin/upload', methods=['POST'])
def api_admin_upload():
    if not require_admin():
        return jsonify({'error': '未授权'}), 401

    if 'video' not in request.files:
        return jsonify({'error': '请选择视频文件'}), 400

    file = request.files['video']
    title = request.form.get('title', '').strip()

    if file.filename == '':
        return jsonify({'error': '请选择视频文件'}), 400

    ext = os.path.splitext(file.filename)[1].lower()
    if ext not in ALLOWED_EXT:
        return jsonify({'error': f'不支持的文件格式 {ext}'}), 400

    # Use title as filename base, fallback to original filename
    base_name = title if title else os.path.splitext(file.filename)[0]
    base_name = _sanitize_html(base_name)
    safe_name = _safe_filename(base_name, ext)
    file.save(os.path.join(DATA_DIR, safe_name))

    now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    videos = read_json('videos.json')
    new_id = _next_video_id(videos)
    new_video = {
        'id': new_id,
        'title': base_name,
        'filename': safe_name,
        'path': f'data/{safe_name}',
        'uploader': '管理员',
        'uploaded_at': now,
        'updated_at': now,
        'play_count': 0,
        'unique_ips': []
    }
    videos.append(new_video)
    write_json('videos.json', videos)

    # Record upload log
    uploads = read_json('uploads.json')
    fp = os.path.join(DATA_DIR, safe_name)
    size_mb = round(os.path.getsize(fp) / (1024 * 1024), 2) if os.path.exists(fp) else 0
    uploads.append({
        'id': len(uploads) + 1,
        'ip': get_client_ip(),
        'uploader': '管理员',
        'title': base_name,
        'filename': safe_name,
        'video_id': new_id,
        'size_mb': size_mb,
        'uploaded_at': now
    })
    write_json('uploads.json', uploads)

    return jsonify({'success': True, 'video': new_video})


@app.route('/api/admin/rename', methods=['POST'])
def api_admin_rename():
    if not require_admin():
        return jsonify({'error': '未授权'}), 401

    data = request.get_json(silent=True) or {}
    vid_id = data.get('id')
    new_title = data.get('title', '').strip()
    new_title = _sanitize_html(new_title)

    if not vid_id or not new_title:
        return jsonify({'error': '参数不完整'}), 400

    videos = read_json('videos.json')
    for v in videos:
        if v['id'] == vid_id:
            old_path = os.path.join(DATA_DIR, v['filename'])
            ext = os.path.splitext(v['filename'])[1]
            safe_name = _safe_filename(new_title, ext)
            new_path = os.path.join(DATA_DIR, safe_name)

            # Rename file on disk
            if os.path.exists(old_path):
                os.rename(old_path, new_path)

            v['title'] = new_title
            v['filename'] = safe_name
            v['path'] = f'data/{safe_name}'
            v['updated_at'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            write_json('videos.json', videos)
            return jsonify({'success': True})

    return jsonify({'error': '视频不存在'}), 404


@app.route('/api/admin/delete', methods=['POST'])
def api_admin_delete():
    if not require_admin():
        return jsonify({'error': '未授权'}), 401

    data = request.get_json(silent=True) or {}
    vid_id = data.get('id')

    if not vid_id:
        return jsonify({'error': '参数不完整'}), 400

    videos = read_json('videos.json')
    target = None
    for v in videos:
        if v['id'] == vid_id:
            target = v
            break

    if not target:
        return jsonify({'error': '视频不存在'}), 404

    # Delete file
    fpath = os.path.join(DATA_DIR, target['filename'])
    if os.path.exists(fpath):
        os.remove(fpath)

    videos = [v for v in videos if v['id'] != vid_id]
    write_json('videos.json', videos)
    return jsonify({'success': True})


# ===================================================================
# API – Share
# ===================================================================

def _gen_token(length=12):
    return ''.join(random.choices(string.ascii_letters + string.digits, k=length))


@app.route('/api/shares/generate', methods=['POST'])
def api_generate_share():
    data = request.get_json(silent=True) or {}
    video_id = data.get('video_id')
    shared_by = (data.get('shared_by') or '').strip()
    if not video_id:
        return jsonify({'error': 'video_id required'}), 400
    if not shared_by:
        return jsonify({'error': 'shared_by required'}), 400

    videos = read_json('videos.json')
    video = next((v for v in videos if v['id'] == video_id), None)
    if not video:
        return jsonify({'error': '视频不存在'}), 404

    shares = read_json('shares.json')

    # Reuse existing token if same person already shared same video
    existing = next((s for s in shares if s['video_id'] == video_id and s.get('shared_by') == shared_by), None)
    if existing:
        share_url = f"{request.host_url}?share={existing['token']}"
        return jsonify({'token': existing['token'], 'share_url': share_url})

    token = _gen_token()
    now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    shares.append({
        'token': token,
        'video_id': video_id,
        'video_title': video['title'],
        'shared_by': shared_by,
        'created_at': now,
        'total_views': 0,
        'unique_ips': []
    })
    write_json('shares.json', shares)

    share_url = f"{request.host_url}?share={token}"
    return jsonify({'token': token, 'share_url': share_url})


@app.route('/api/shares/<token>', methods=['GET'])
def api_resolve_share(token):
    shares = read_json('shares.json')
    share = next((s for s in shares if s['token'] == token), None)
    if not share:
        return jsonify({'error': '分享链接无效或已过期'}), 404

    videos = read_json('videos.json')
    video = next((v for v in videos if v['id'] == share['video_id']), None)
    if not video:
        return jsonify({'error': '该视频已被删除'}), 410
    if not share.get('enabled', True):
        return jsonify({'error': '该分享链接已被禁用'}), 410

    # Track view
    ip = get_client_ip()
    share['total_views'] = share.get('total_views', 0) + 1
    if ip not in share.setdefault('unique_ips', []):
        share['unique_ips'].append(ip)
    write_json('shares.json', shares)

    return jsonify({
        'id': video['id'],
        'title': video['title'],
        'path': video['path'],
        'play_count': len(video.get('unique_ips', [])),
        'share_views': share.get('total_views', 0),
        'share_unique_views': len(share.get('unique_ips', []))
    })


@app.route('/api/admin/shares', methods=['GET'])
def api_admin_shares():
    if not require_admin():
        return jsonify({'error': '未授权'}), 401

    shares = read_json('shares.json')
    result = []
    for s in shares:
        result.append({
            'token': s['token'],
            'video_id': s.get('video_id', 0),
            'video_title': s['video_title'],
            'shared_by': s.get('shared_by', ''),
            'created_at': s.get('created_at', ''),
            'total_views': s.get('total_views', 0),
            'unique_views': len(s.get('unique_ips', [])),
            'enabled': s.get('enabled', True),
            'share_url': f"{request.host_url}?share={s['token']}"
        })
    result.reverse()
    return jsonify(result)


@app.route('/api/admin/shares/toggle', methods=['POST'])
def api_admin_toggle_share():
    if not require_admin():
        return jsonify({'error': '未授权'}), 401

    data = request.get_json(silent=True) or {}
    token = data.get('token', '')
    if not token:
        return jsonify({'error': 'token required'}), 400

    shares = read_json('shares.json')
    for s in shares:
        if s['token'] == token:
            s['enabled'] = not s.get('enabled', True)
            write_json('shares.json', shares)
            return jsonify({'success': True, 'enabled': s['enabled']})

    return jsonify({'error': '分享链接不存在'}), 404


@app.route('/api/admin/shares/delete', methods=['POST'])
def api_admin_delete_share():
    if not require_admin():
        return jsonify({'error': '未授权'}), 401

    data = request.get_json(silent=True) or {}
    token = data.get('token', '')
    if not token:
        return jsonify({'error': 'token required'}), 400

    shares = read_json('shares.json')
    before = len(shares)
    shares = [s for s in shares if s['token'] != token]
    if len(shares) == before:
        return jsonify({'error': '分享链接不存在'}), 404

    write_json('shares.json', shares)
    return jsonify({'success': True})


@app.route('/api/admin/uploads', methods=['GET'])
def api_admin_uploads():
    if not require_admin():
        return jsonify({'error': '未授权'}), 401

    uploads = read_json('uploads.json')
    uploads.reverse()
    return jsonify(uploads)


# ===================================================================
# Static file serving
# ===================================================================

@app.route('/')
def serve_index():
    return send_from_directory(ROOT_DIR, 'index.html')


@app.route('/admin')
def serve_admin():
    return send_from_directory(ROOT_DIR, 'admin.html')


@app.route('/data/<path:filename>')
def serve_video(filename):
    return send_from_directory(DATA_DIR, filename)


# ===================================================================
# Startup
# ===================================================================

if __name__ == '__main__':
    sync_database()
    print('* Server running on http://0.0.0.0:8088')
    app.run(host='0.0.0.0', port=8088, debug=os.environ.get('FLASK_DEBUG', '0') == '1')
